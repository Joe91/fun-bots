from .ctk_canvas import CTkCanvas

CTkCanvas.init_font_character_mapping()
